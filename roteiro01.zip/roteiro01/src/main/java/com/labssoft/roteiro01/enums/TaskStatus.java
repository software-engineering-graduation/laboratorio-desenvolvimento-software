package com.labssoft.roteiro01.enums;

public enum TaskStatus {
    InProgress,
    Completed
}
